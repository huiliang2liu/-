package com.text;

public class ClassText {
	public static String test(String test) {
		System.out.println(ClassText.class.getName()+test);
		return ClassText.class.getName();
	}
}
