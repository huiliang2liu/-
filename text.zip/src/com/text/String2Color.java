package com.text;

public class String2Color {
	private static final int f = Integer.valueOf("f", 16);
	private static final int ff = Integer.valueOf("ff", 16);

	public static int color(String string) {
		return 0;
	}
}
