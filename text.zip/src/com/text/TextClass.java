package com.text;

import java.util.Arrays;
import java.util.List;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.NativeJavaObject;
import org.mozilla.javascript.NativeObject;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;

public class TextClass {
	public static void main(String[] args) {
		String[] strings={"dadad","adad","adad","adad"};
		List<String> list=Arrays.asList(strings);
		System.out.println(System.currentTimeMillis());
		// TextClass text = new TextClass();
		// System.out.println(text.runScript(JAVA_CALL_JS_FUNCTION, "Test", new
		// String[]{"nihao"}));
		// try {
		// System.out.println(text.runScript(JS_CALL_JAVA_FUNCTION, "Test", new
		// String[]{}));
		// } catch (Exception e) {
		// // TODO: handle exception
		// e.printStackTrace();
		// }
//		String testjs =
////				"var val = getValue('testKey');" +
//                "setValue('����js����','java���������');";
////		String testjs = "var test = getObjectValue('objectKey');"
////				+ "setValue('testvalue',test.name);";
//		JSEngine engine = new JSEngine();
//		engine.runScript(testjs);
	}

	/** Javaִ��js�ķ��� */
	private static final String JAVA_CALL_JS_FUNCTION = "function Test(url){ return 'ũ�񲮲� java call js Rhino '+url; }";
	/** js����Java�еķ��� */
	private static final String JS_CALL_JAVA_FUNCTION = //
	"var ScriptAPI = java.lang.Class.forName(\""
			+ TextClass.class.getName()
			+ "\", true, javaLoader);"
			+ //
			"var methodRead = ScriptAPI.getMethod(\"jsCallJava\", [java.lang.String]);"
			+ //
			"function jsCallJava(url) {return methodRead.invoke(javaContext, url);}"
			+ //
			"function Test(){ return jsCallJava('daad'); }";

	/**
	 * ִ��JS
	 * 
	 * @param js
	 *            js����
	 * @param functionName
	 *            js��������
	 * @param functionParams
	 *            js��������
	 * @return
	 */
	public String runScript(String js, String functionName,
			Object[] functionParams) {
		Context rhino = Context.enter();
		rhino.setOptimizationLevel(-1);
		try {
			Scriptable scope = rhino.initStandardObjects();
			ScriptableObject.putProperty(scope, "javaContext",
					Context.javaToJS(this, scope));
			ScriptableObject.putProperty(scope, "javaLoader",
					Context.javaToJS(TextClass.class.getClassLoader(), scope));
			rhino.evaluateString(scope, js, "", 1, null);
			Function function = (Function) scope.get(functionName, scope);
			Object result = function.call(rhino, scope, scope, functionParams);
			if (result instanceof String) {
				return (String) result;
			} else if (result instanceof NativeJavaObject) {
				return (String) ((NativeJavaObject) result)
						.getDefaultValue(String.class);
			} else if (result instanceof NativeObject) {
				return (String) ((NativeObject) result)
						.getDefaultValue(String.class);
			}
			return result.toString();// (String) function.call(rhino, scope,
										// scope, functionParams);
		} finally {
			Context.exit();
		}
	}

	public String jsCallJava(String url) {
		return "ũ�񲮲� js call Java Rhino  " + url;
	}

}
