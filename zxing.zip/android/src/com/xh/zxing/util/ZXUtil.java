package com.xh.zxing.util;

import java.util.HashMap;
import java.util.Map;

import android.graphics.Bitmap;
import android.graphics.Canvas;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.ChecksumException;
import com.google.zxing.EncodeHintType;
import com.google.zxing.FormatException;
import com.google.zxing.NotFoundException;
import com.google.zxing.RGBLuminanceSource;
import com.google.zxing.Result;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.qrcode.QRCodeReader;
import com.google.zxing.qrcode.QRCodeWriter;

/**
 * CaptureActivity com.xh.zxing.util 2018 2018-4-26 下午5:49:06 instructions：
 * author:liuhuiliang email:825378291@qq.com
 **/

public class ZXUtil {
	public static Bitmap generateBitmap(String content, int width, int height) {
		QRCodeWriter qrCodeWriter = new QRCodeWriter();
		Map<EncodeHintType, String> hints = new HashMap<>();
		hints.put(EncodeHintType.CHARACTER_SET, "utf-8");
		try {
			BitMatrix encode = qrCodeWriter.encode(content,
					BarcodeFormat.QR_CODE, width, height, hints);
			int[] pixels = new int[width * height];
			for (int i = 0; i < height; i++) {
				for (int j = 0; j < width; j++) {
					if (encode.get(j, i)) {
						pixels[i * width + j] = 0x00000000;
					} else {
						pixels[i * width + j] = 0xffffffff;
					}
				}
			}
			return Bitmap.createBitmap(pixels, 0, width, width, height,
					Bitmap.Config.RGB_565);
		} catch (WriterException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static Bitmap addLogo(Bitmap qrBitmap, Bitmap logoBitmap) {
		int qrBitmapWidth = qrBitmap.getWidth();
		int qrBitmapHeight = qrBitmap.getHeight();
		int logoBitmapWidth = logoBitmap.getWidth();
		int logoBitmapHeight = logoBitmap.getHeight();
		Bitmap blankBitmap = Bitmap.createBitmap(qrBitmapWidth, qrBitmapHeight,
				Bitmap.Config.ARGB_8888);
		Canvas canvas = new Canvas(blankBitmap);
		canvas.drawBitmap(qrBitmap, 0, 0, null);
		canvas.save(Canvas.ALL_SAVE_FLAG);
		float scaleSize = 1.0f;
		while ((logoBitmapWidth / scaleSize) > (qrBitmapWidth / 5)
				|| (logoBitmapHeight / scaleSize) > (qrBitmapHeight / 5)) {
			scaleSize *= 2;
		}
		float sx = 1.0f / scaleSize;
		canvas.scale(sx, sx, qrBitmapWidth / 2, qrBitmapHeight / 2);
		canvas.drawBitmap(logoBitmap, (qrBitmapWidth - logoBitmapWidth) / 2,
				(qrBitmapHeight - logoBitmapHeight) / 2, null);
		canvas.restore();
		return blankBitmap;
	}

	public static String read(Bitmap bitmap) {
		int width = bitmap.getWidth();
		int height = bitmap.getHeight();
		int[] data = new int[width * height];
		bitmap.getPixels(data, 0, width, 0, 0, width, height);
		RGBLuminanceSource source = new RGBLuminanceSource(width, height, data);
		BinaryBitmap bitmap1 = new BinaryBitmap(new HybridBinarizer(source));
		QRCodeReader reader = new QRCodeReader();
		Result re = null;
		try {
			re = reader.decode(bitmap1);
		} catch (NotFoundException e) {
			e.printStackTrace();
		} catch (ChecksumException e) {
			e.printStackTrace();
		} catch (FormatException e) {
			e.printStackTrace();
		}
		return re == null ? "读取二维码失败" : re.getText();
	}
}
