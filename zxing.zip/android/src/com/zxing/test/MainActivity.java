package com.zxing.test;

import java.util.HashMap;
import java.util.Map;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.client.android.R;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.xh.zxing.util.ZXUtil;

/**
 * CaptureActivity com.zxing.test 2018 2018-4-26 下午5:03:23 instructions：
 * author:liuhuiliang email:825378291@qq.com
 **/

public class MainActivity extends Activity implements OnClickListener {
	private ImageView image_view;
	private TextView read_text;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main_activity);
		image_view = (ImageView) findViewById(R.id.image_view);
		findViewById(R.id.create).setOnClickListener(this);
		findViewById(R.id.read).setOnClickListener(this);
		read_text = (TextView) findViewById(R.id.read_text);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (v.getId() == R.id.read) {
			read_text.setText(ZXUtil.read(BitmapFactory.decodeResource(
					getResources(), R.drawable.liuhuiliang)));
			return;
		}
		LayoutParams lp = image_view.getLayoutParams();
		image_view.setImageBitmap(ZXUtil.addLogo(ZXUtil.generateBitmap(
				"liuhuiliang", lp.width, lp.height), BitmapFactory
				.decodeResource(getResources(), R.drawable.launcher_icon)));
	}

}
